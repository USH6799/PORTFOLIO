# if u see the code of big coders and programmers u will notice if __name__ = __main__:

# Imagine i am importing my own module in this program like module1.py

# Please save CustomModule file from the same list in the website and save it in same directory to view.

import module1 # importing the module , module1

# if u run this program then it will show the output of the module1.py file.

# Because when we import the module , we dont only import the methods of the module but also the rest code also, and in module1 there is a call for the method, so it is also called from here.

module1.welcome() # calling the function from module1

# OUTPUT:- Welcome From USH
#          Welcome From USH

# As you saw there are two outputs in the terminal, one from module1.py and another from this program.

# but what if we dont want the method to run automatically by itself. 

# then we can use if block to check whether it is automatically running or not.

# Inside the imported module You have to write,

# if __name__ == "__main__":
#   welcome()

# now lets breakdown it and understand, as you saw __name__ refers to the program from where it is called, like inside the module module1 the value of __name__ will be __main__ and inside the program it will be module1.

# Now if you run this program , u will see the output only one time not 2 times.

# OUTPUT:- Welcome From USH
