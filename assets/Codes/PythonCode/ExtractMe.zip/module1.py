def welcome(): # function defination taking no parameter and no return value
    
    print("Welcome From USH") # function body printing the welcome message

print(__name__) # here the value of __name__ is __main__

# welcome() 
# remove the below all code and comment out or remove the comment of above func and run the main.py file in which this module is imported, u will see the same output 2 times.

# Then again comment the above welcome() func and  write the whole if part again and run the main.py and u will see only one output.

if __name__ == "__main__": # checking if the value inside __name__ is equal to string value or not, which means if this program will run from here, then if code will run but if this module is exported to any other program and runned then this will not execute if code because __name__ will be not equal to __main__ in other programs.
    
  welcome()

# OUTPUT:- Welcome From USH
    